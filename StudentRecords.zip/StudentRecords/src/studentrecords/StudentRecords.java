package studentrecords;

import java.util.Scanner;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import java.sql.*;

public class StudentRecords {
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    static final String DBASE_URL = "jdbc:mysql://localhost/Records?autoReconnect=true&useSSL=false";

    //  Database credentials
    static final String USERNAME = "root";
    static final String PASSWORD = "";
    static final Scanner kb = new Scanner(System.in);
    

    public static void main(String[] args) {
        StudentRecords sr = new StudentRecords();
        sr.mainMenu();
    }//end main
    
    public static void mainMenu(){
        int choice = 0;
        do {
            System.out.println("+----------------------------+");
            System.out.println("|   M E N U  O P T I O N S   |");
            System.out.println("+----------------------------+");
            System.out.println("| 1. Accounts                |");
            System.out.println("| 2. Subjects                |");
            System.out.println("| 3. Classes                 |");
            System.out.println("| 4. Enrollment              |");
            System.out.println("| 5. Exit Program            |");
            System.out.println("+----------------------------+");
            do {
                System.out.print("Enter your choice: ");
                try {
                    choice = Integer.parseInt(kb.nextLine());
                } catch (Exception e) {
                    System.out.println("error: input a valid value...");
                    System.out.print("Press enter key to continue...");
                    kb.nextLine();
                }
            } while(choice < 1 || choice > 5);

            switch (choice){
                case 1:
                    accountsMenu(choice, kb);
                    break;
                case 2:
                    subjectsMenu(choice, kb);
                    break;
                case 3:
                    classesMenu(choice, kb);
                    break;
                case 4:
                    enrollmentMenu(choice, kb);
                    break;
            }

        } while(choice != 5);
        kb.close();
    }

    public static void accountsMenu(int choice, Scanner kb){
        do {
            System.out.println("+----------------------------+");
            System.out.println("|   M E N U  O P T I O N S   |");
            System.out.println("+----------------------------+");
            System.out.println("| 0. Back                    |");
            System.out.println("| 1. Add Account             |");
            System.out.println("| 2. Check Account           |");
            System.out.println("| 3. Update Account          |");
            System.out.println("| 4. Delete Account          |");
            System.out.println("+----------------------------+");
            do {
                System.out.print("Enter your choice: ");
                try {
                    choice = Integer.parseInt(kb.nextLine());
                } catch (Exception e) {
                    System.out.println("error: input a valid value...");
                    System.out.print("Press enter key to continue...");
                    kb.nextLine();
                }
            } while(choice < 0 || choice > 4);
            switch (choice){
                case 1:
                    //To-Do
                    break;
                case 2:
                    listAccounts();
                    break;
                case 3:
                    //To-Do
                    break;
                case 4:
                    //To-Do
                    break;
            }
        } while (choice != 0);
    }

    public static void subjectsMenu(int choice, Scanner kb){
        do {
            System.out.println("+----------------------------+");
            System.out.println("|   M E N U  O P T I O N S   |");
            System.out.println("+----------------------------+");
            System.out.println("| 0. Back                    |");
            System.out.println("| 1. Add Subject             |");
            System.out.println("| 2. Check Subject           |");
            System.out.println("| 3. Update Subject          |");
            System.out.println("| 4. Delete Subject          |");
            System.out.println("+----------------------------+");
            do {
                System.out.print("Enter your choice: ");
                try {
                    choice = Integer.parseInt(kb.nextLine());
                } catch (Exception e) {
                    System.out.println("error: input a valid value...");
                    System.out.print("Press enter key to continue...");
                    kb.nextLine();
                }
            } while(choice < 0 || choice > 4);
            switch (choice){
                case 1:
                    //To-Do
                    break;
                case 2:
                    listSubjects();
                    break;
                case 3:
                    //To-Do
                    break;
                case 4:
                    //To-Do
                    break;
            }
        } while (choice != 0);
    }

    public static void classesMenu(int choice, Scanner kb){
        do {
            System.out.println("+----------------------------+");
            System.out.println("|   M E N U  O P T I O N S   |");
            System.out.println("+----------------------------+");
            System.out.println("| 0. Back                    |");
            System.out.println("| 1. Add Class               |");
            System.out.println("| 2. Check Class             |");
            System.out.println("| 3. Update Class            |");
            System.out.println("| 4. Delete Class            |");
            System.out.println("+----------------------------+");
            do {
                System.out.print("Enter your choice: ");
                try {
                    choice = Integer.parseInt(kb.nextLine());
                } catch (Exception e) {
                    System.out.println("error: input a valid value...");
                    System.out.print("Press enter key to continue...");
                    kb.nextLine();
                }
            } while(choice < 0 || choice > 4);
            switch (choice){
                case 1:
                    //To-Do
                    break;
                case 2:
                    listClasses();
                    break;
                case 3:
                    //To-Do
                    break;
                case 4:
                    //To-Do
                    break;
            }
        } while (choice != 0);
    }

    public static void enrollmentMenu(int choice, Scanner kb){
        do {
            System.out.println("+----------------------------+");
            System.out.println("|   M E N U  O P T I O N S   |");
            System.out.println("+----------------------------+");
            System.out.println("| 0. Back                    |");
            System.out.println("| 1. Enroll                  |");
            System.out.println("| 2. Check Enrollment        |");
            System.out.println("| 3. Update Info             |");
            System.out.println("| 4. Unenroll                |");
            System.out.println("+----------------------------+");
            do {
                System.out.print("Enter your choice: ");
                try {
                    choice = Integer.parseInt(kb.nextLine());
                } catch (Exception e) {
                    System.out.println("error: input a valid value...");
                    System.out.print("Press enter key to continue...");
                    kb.nextLine();
                }
            } while(choice < 0 || choice > 4);
            
            switch (choice){
                case 1:
                    //To-Do
                    break;
                case 2:
                    listEnrolls();
                    break;
                case 3:
                    //To-Do
                    break;
                case 4:
                    //To-Do
                    break;
            }
        } while (choice != 0);
    }
    
    public static void listAccounts(){
        Connection conn = null;
        Statement stmt = null;
        try{
           //STEP 2: Register JDBC driver
           Class.forName("com.mysql.jdbc.Driver");

           //STEP 3: Open a connection
           System.out.println("Connecting to database...");
           conn = DriverManager.getConnection(DBASE_URL,USERNAME,PASSWORD);

           //STEP 4: Execute a query
           System.out.println("Creating statement...");
           stmt = conn.createStatement();

           String sql;
           sql = "SELECT * FROM students";
           ResultSet rs = stmt.executeQuery(sql);

           //STEP 5: Extract data from result set
           while(rs.next()){
              //Retrieve by column name
              int idNumber  = rs.getInt("idNumber");
              String lastName = rs.getString("lastName");
              String firstName = rs.getString("firstName");
              String midInitial = rs.getString("midInitial");
              String gender = rs.getString("gender");
              String contactNo = rs.getString("contactNo");
              String emailAdd = rs.getString("emailAdd");

              //Display values
              System.out.println("ID Number:      " +idNumber);
              System.out.println("Last Name:      " +lastName);
              System.out.println("First Name:     " +firstName);
              System.out.println("Middle Initial: " +midInitial);
              System.out.println("Gender:         " +gender);
              System.out.println("Contact Number: " +contactNo);
              System.out.println("Email Address:  " +emailAdd);
              System.out.println("-----------------------------------");
              kb.nextLine();
           }
           //STEP 6: Clean-up environment
           rs.close();
           stmt.close();
           conn.close();
        }catch(SQLException se){
           //Handle errors for JDBC
           se.printStackTrace();
        }catch(Exception e){
           //Handle errors for Class.forName
           e.printStackTrace();
        }finally{
           //finally block used to close resources
           try{
              if(stmt!=null)
                 stmt.close();
           }catch(SQLException se2){
           }// nothing we can do
           try{
              if(conn!=null)
                 conn.close();
           }catch(SQLException se){
              se.printStackTrace();
           }//end finally try
        }//end try
       
    }// end of listaccounts
    
    public static void listSubjects(){
        Connection conn = null;
        Statement stmt = null;
        try{
           //STEP 2: Register JDBC driver
           Class.forName("com.mysql.jdbc.Driver");

           //STEP 3: Open a connection
           System.out.println("Connecting to database...");
           conn = DriverManager.getConnection(DBASE_URL,USERNAME,PASSWORD);

           //STEP 4: Execute a query
           System.out.println("Creating statement...");
           stmt = conn.createStatement();
           System.out.println();
           
           String sql;
           sql = "SELECT * FROM subjects";
           ResultSet rs = stmt.executeQuery(sql);

           //STEP 5: Extract data from result set
           while(rs.next()){
              //Retrieve by column name
              int subjID  = rs.getInt("subjdid");
              String title = rs.getString("title");
              String day = rs.getString("day");
              int units = rs.getInt("units");

              //Display values
              System.out.println("Subejct ID:   " +subjID);
              System.out.println("Title:        " +title);
              System.out.println("Day/s:        " +day);
              System.out.println("Units:        " +units);
              System.out.println("-----------------------------------");
              kb.nextLine();
           }
           //STEP 6: Clean-up environment
           rs.close();
           stmt.close();
           conn.close();
        }catch(SQLException se){
           //Handle errors for JDBC
           se.printStackTrace();
        }catch(Exception e){
           //Handle errors for Class.forName
           e.printStackTrace();
        }finally{
           //finally block used to close resources
           try{
              if(stmt!=null)
                 stmt.close();
           }catch(SQLException se2){
           }// nothing we can do
           try{
              if(conn!=null)
                 conn.close();
           }catch(SQLException se){
              se.printStackTrace();
           }//end finally try
        }//end try
       
    }// end listSubject
    
    public static void listClasses(){
        Connection conn = null;
        Statement stmt = null;
        try{
           //STEP 2: Register JDBC driver
           Class.forName("com.mysql.jdbc.Driver");

           //STEP 3: Open a connection
           System.out.println("Connecting to database...");
           conn = DriverManager.getConnection(DBASE_URL,USERNAME,PASSWORD);

           //STEP 4: Execute a query
           System.out.println("Creating statement...");
           stmt = conn.createStatement();
           System.out.println();
           
           String sql;
           sql = "SELECT * FROM class";
           ResultSet rs = stmt.executeQuery(sql);

           //STEP 5: Extract data from result set
           while(rs.next()){
              //Retrieve by column name
              String classCode = rs.getString("classcode");
              String time = rs.getString("time");
              String day = rs.getString("day");
              int subjID = rs.getInt("subjid");

              //Display values
              System.out.println("Classcode:  " +classCode);
              System.out.println("Time:       " +time);
              System.out.println("Day:        " +day);
              System.out.println("Subejct ID: " +subjID);
              System.out.println("-----------------------------------");
              kb.nextLine();
           }
           //STEP 6: Clean-up environment
           rs.close();
           stmt.close();
           conn.close();
        }catch(SQLException se){
           //Handle errors for JDBC
           se.printStackTrace();
        }catch(Exception e){
           //Handle errors for Class.forName
           e.printStackTrace();
        }finally{
           //finally block used to close resources
           try{
              if(stmt!=null)
                 stmt.close();
           }catch(SQLException se2){
           }// nothing we can do
           try{
              if(conn!=null)
                 conn.close();
           }catch(SQLException se){
              se.printStackTrace();
           }//end finally try
        }//end try
       
    }// end of listClasses
    
    public static void listEnrolls(){
        Connection conn = null;
        Statement stmt = null;
        try{
           //STEP 2: Register JDBC driver
           Class.forName("com.mysql.jdbc.Driver");

           //STEP 3: Open a connection
           System.out.println("Connecting to database...");
           conn = DriverManager.getConnection(DBASE_URL,USERNAME,PASSWORD);

           //STEP 4: Execute a query
           System.out.println("Creating statement...");
           stmt = conn.createStatement();
           System.out.println();
           
           String sql;
           sql = "SELECT * FROM enroll";
           ResultSet rs = stmt.executeQuery(sql);

           //STEP 5: Extract data from result set
            System.out.println("Classcode   ID Number      Date Submitted");   //Retrieve by column name
            
            while(rs.next()){
           
              String classCode = rs.getString("classcode");
              String idNumber = rs.getString("idno");
              String dateSub = rs.getString("datesubmitted");

              //Display values
              System.out.println(classCode+"        "+idNumber+"        "+dateSub);
           }
            System.out.println();
            System.out.print("Press Enter To Continue...");
            kb.nextLine();
           //STEP 6: Clean-up environment
           rs.close();
           stmt.close();
           conn.close();
        }catch(SQLException se){
           //Handle errors for JDBC
           se.printStackTrace();
        }catch(Exception e){
           //Handle errors for Class.forName
           e.printStackTrace();
        }finally{
           //finally block used to close resources
           try{
              if(stmt!=null)
                 stmt.close();
           }catch(SQLException se2){
           }// nothing we can do
           try{
              if(conn!=null)
                 conn.close();
           }catch(SQLException se){
              se.printStackTrace();
           }//end finally try
        }//end try   
    }// end of listEnrolls
    
}//end StudentRecords

